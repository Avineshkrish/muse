<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1080" preserveAspectRatio="none">
<polygon points="600,1079.5 0,1079.5 0,55.5 300,405.5 600,55.5 "/>
</svg>
