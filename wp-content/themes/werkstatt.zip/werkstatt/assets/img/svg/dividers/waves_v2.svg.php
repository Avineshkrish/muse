<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1080" preserveAspectRatio="none">
	<path d="M-0.416,444.825c44.785,199.687,119.287,289.238,234.217-181.766c175.688-719.987,365.783,289.26,365.783,289.26
		L599.468,1080H-0.416V444.825z"/>
</svg>
