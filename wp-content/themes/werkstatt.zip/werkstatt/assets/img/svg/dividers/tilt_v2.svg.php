<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1080" preserveAspectRatio="none">
<polygon points="0,1079.5 600,1079.5 600,115.5 0,445.5 "/>
</svg>
