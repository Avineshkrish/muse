<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1080" preserveAspectRatio="none">
	<path d="M599.584,444.825c-44.785,199.687-119.287,289.238-234.217-181.766C189.68-456.929-0.417,552.318-0.417,552.318L-0.3,1080
		h599.884V444.825z"/>
</svg>