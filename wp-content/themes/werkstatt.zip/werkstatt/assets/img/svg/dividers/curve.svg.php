<svg class="thb-svg-divider" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1080" preserveAspectRatio="none">
	<path d="M300,406.63c-129.204,0-229.756-195.573-300-398V1079.5h600V8.169C532.815,196.944,434.237,406.63,300,406.63z"/>
</svg>
