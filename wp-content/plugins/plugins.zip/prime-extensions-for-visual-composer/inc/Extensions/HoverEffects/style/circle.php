<?php
if ( $style=='circle' && $circle_effects=='effect1' ){
    
            $output .= '<div class="ih-item circle effect1 '.$css_class.'"  background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none;"> <img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <div class="info-back" >
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }
        
        if ( $style=='circle' && $circle_effects=='effect2' ){
    
            $output .= '<div class="ih-item circle effect2 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
                
        if ( $style=='circle' && $circle_effects=='effect3' ){
    
            $output .= '<div class="ih-item circle effect3 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
        
        if ( $style=='circle' && $circle_effects=='effect4' ){
    
            $output .= '<div class="ih-item circle effect4 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
        
        if ( $style=='circle' && $circle_effects=='effect5' ){
    
            $output .= '<div class="ih-item circle effect5 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info">
                                <div class="info-back" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }        
 

        if ( $style=='circle' && $circle_effects=='effect6' ){
    
            $output .= '<div class="ih-item circle effect6 scale_down_up '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='circle' && $circle_effects=='effect7' ){
    
            $output .= '<div class="ih-item circle effect7 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                                <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info">
                                <div class="info-back" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }
        
        if ( $style=='circle' && $circle_effects=='effect8' ){
    
                        $output .= '<div class="ih-item circle effect8 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                                                                <div class="img-container">
                                                                    <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                                                </div>
                                                                <div class="info-container">
                                                                    <div class="info" style="background:'.$color.'">
                                                                        <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font.'px; color:'.$heading_color.';">'.$title.'</h3>
                                                                        <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                                                                    </div>
                                </div></a></div>';
        }        
        
        if ( $style=='circle' && $circle_effects=='effect9' ){
    
            $output .= '<div class="ih-item circle effect9 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
                
        if ( $style=='circle' && $circle_effects=='effect10' ){
    
            $output .= '<div class="ih-item circle effect10 top_to_bottom '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }      
          
        if ( $style=='circle' && $circle_effects=='effect11' ){
    
            $output .= '<div class="ih-item circle effect11 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }        
        
        if ( $style=='circle' && $circle_effects=='effect12' ){
    
            $output .= '<div class="ih-item circle effect12 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='circle' && $circle_effects=='effect13' ){
    
            $output .= '<div class="ih-item circle effect13 from_left_and_right '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                                <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info">
                                <div class="info-back" style="background:'.$color.'">
									<h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
									<p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
								</div>
					</div></a></div>';
        }
        
        if ( $style=='circle' && $circle_effects=='effect14' ){
    
            $output .= '<div class="ih-item circle effect14 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }        
        
        if ( $style=='circle' && $circle_effects=='effect15' ){
    
            $output .= '<div class="ih-item circle effect15 left_to_right '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }        
        
        if ( $style=='circle' && $circle_effects=='effect16' ){
    
            $output .= '<div class="ih-item circle effect16 left_to_right '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }         
        
        if ( $style=='circle' && $circle_effects=='effect17' ){
    
            $output .= '<div class="ih-item circle effect17 '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }         
        
        if ( $style=='circle' && $circle_effects=='effect18' ){
    
            $output .= '<div class="ih-item circle effect18 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info">
                                <div class="info-back" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }    
            
        if ( $style=='circle' && $circle_effects=='effect19' ){
    
            $output .= '<div class="ih-item circle effect19 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="box-shadow:none; width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }        

        if ( $style=='circle' && $circle_effects=='effect20' ){
    
            $output .= '<div class="ih-item circle effect20 '.$animation.' '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_width.'px;background:'.$color.'"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="width:'.$image_width.'px; height:'.$image_width.'px;"><img src="'.$image[0].'"></div>
                                    <div class="info">
                                <div class="info-back" style="background:'.$color.'">
                                <h3 style="letter-spacing: 0px; margin-top: '.$move_texts.'px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; border-top: '.$remove_underline.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }        
        	
		