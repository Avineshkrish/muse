<?php
	if ( $style=='square' && $square_effects == 'effect1' ){
    
            $output .= '<div class="ih-item square effect1 left_and_right '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }          
        if ( $style=='square' && $square_effects=='effect2' ){
    
            $output .= '<div class="ih-item square effect2 '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }        

        if ( $style=='square' && $square_effects=='effect3' ){
    
            $output .= '<div class="ih-item square effect3 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect4' ){
    
            $output .= '<div class="ih-item square effect4 '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                            <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                            <div class="mask1" style="position: absolute; height: '.$image_height.'px; width: '.$image_width.'px;; left: auto; right: 0px; top: 0px;"></div>
                            <div class="mask2" style="position: absolute; height: '.$image_height.'px; width: '.$image_width.'px; top: auto; bottom: 0px; left: 0px;"></div>
                            <div class="info" style="background:'.$color.'">
                              <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                              <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect5' ){
    
            $output .= '<div class="ih-item square effect5 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect6' ){
    
            $output .= '<div class="ih-item square effect6 from_top_and_bottom '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect7' ){
    
            $output .= '<div class="ih-item square effect7 '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
        
        if ( $style=='square' && $square_effects=='effect8' ){
    
            $output .= '<div class="ih-item square effect8 scale_up '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
        
        if ( $style=='square' && $square_effects=='effect9' ){
    
            $output .= '<div class="ih-item square effect9 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img" style="height: '.$image_height.'px; background:'.$color.'"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info">
                                    <div class="info-back"  style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></div></a></div>';
        }
        
        if ( $style=='square' && $square_effects=='effect10' ){
    
            $output .= '<div class="ih-item square effect10 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect11' ){
    
            $output .= '<div class="ih-item square effect11 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }
        
        if ( $style=='square' && $square_effects=='effect12' ){
    
            $output .= '<div class="ih-item square effect12 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect13' ){
    
            $output .= '<div class="ih-item square effect13 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect14' ){
    
            $output .= '<div class="ih-item square effect14 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }

        if ( $style=='square' && $square_effects=='effect15' ){
    
            $output .= '<div class="ih-item square effect15 '.$animation.' '.$css_class.'" style="background:'.$color.'; height: '.$image_height.'px; width: '.$image_width.'px;"><a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                            <div class="spinner"></div>
                                <div class="img"><img style="height: '.$image_height.'px;" src="'.$image[0].'"></div>
                                    <div class="info" style="background:'.$color.'">
                                <h3 style="font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.'; margin-top: '.$move_texts.'px">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                    
                    </div></a></div>';
        }