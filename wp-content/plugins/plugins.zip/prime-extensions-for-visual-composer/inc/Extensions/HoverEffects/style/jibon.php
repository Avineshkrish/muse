<?php
 if ( $style=='jibon' && $jibon_effects=='effect1' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption top-to-bottom">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
        }

        if ( $style=='jibon' && $jibon_effects=='effect2' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption bottom-to-top">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }          

        if ( $style=='jibon' && $jibon_effects=='effect3' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption left-to-right">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        
        if ( $style=='jibon' && $jibon_effects=='effect4' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption right-to-left">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }

        if ( $style=='jibon' && $jibon_effects=='effect5' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption rotate-in">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect6' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption rotate-out">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect7' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption open-up">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }

        if ( $style=='jibon' && $jibon_effects=='effect8' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption open-down">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect9' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption open-left">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect10' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption open-right">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect11' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption come-left">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }
        if ( $style=='jibon' && $jibon_effects=='effect12' ){
    
            $output .= '<div class="style4">
                            <div style="max-width: '.$image_width.'px; max-height: '.$image_height.'px;" class="pic">
                        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <img src="'.$image[0].'" class="pic-image">
                            <span class="pic-caption come-right">
                                <h1 style="font-size: '.$heading_font_size.'px; font-family: '.$font.'; color: '.$heading_color.';" class="pic-title">'.$title.'</h1>
                                <p style="font-size: 13px; font-family: '.$font.'; color: '.$desc_color.';">'.$description.'</p>
                            </span>
                        </a>
                        </div>
                    </div>';
                    
        }