<?php

if ( $style=='caption' && $caption_effects=='effect1' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption spaceoutleft-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }     
           
        if ( $style=='caption' && $caption_effects=='effect2' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption spaceoutup-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect3' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption spaceoutdown-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect4' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption spaceoutright-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        } 
        
        if ( $style=='caption' && $caption_effects=='effect5' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box" style="perspective: 2500px; perspective-origin: 50% 50%;">
                <div class="caption flip-image-horizontal captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect6' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box" style="perspective: 2500px; perspective-origin: 50% 50%;">
                <div class="caption flip-image-horizontal captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }
        

        if ( $style=='caption' && $caption_effects=='effect7' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box" style="perspective: 2500px; perspective-origin: 50% 50%;">
                <div class="caption page-turn-from-top captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }       
        
                
        if ( $style=='caption' && $caption_effects=='effect8' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box" style="perspective: 2500px; perspective-origin: 50% 50%;">
                <div class="caption page-turn-from-bottom captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect9' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption swap-caption captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect10' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption rotateup-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        } 
        
        
        if ( $style=='caption' && $caption_effects=='effect11' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption rotatedown-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect12' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption fall-down-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect13' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption zoom-image-out-caption-twist captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }                        

        if ( $style=='caption' && $caption_effects=='effect14' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption opendoorup-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }        
        
        if ( $style=='caption' && $caption_effects=='effect15' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption tinright-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }

        if ( $style=='caption' && $caption_effects=='effect16' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption rotateleft-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }

        if ( $style=='caption' && $caption_effects=='effect17' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption opendoorleft-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }

        if ( $style=='caption' && $caption_effects=='effect18' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption simple-fade captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }

        if ( $style=='caption' && $caption_effects=='effect19' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption foolish-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }

        if ( $style=='caption' && $caption_effects=='effect20' ){
    
            $output .= '<div  class="wcp-caption-plugin '.$css_class.'" style="width:'.$image_width.'px; height:'.$image_height.'px;box-shadow: 1px 2px 2px #cacaca;border-radius: ;">

        <a href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
        
            <div class="image-caption-box">
                <div class="caption opendoorright-image captiontext" style="width:'.$image_width.'px; height:'.$image_height.'px; background-color: '.$color.'; color: ; opacity: ;">
                        <div style="display:table; height:100%; width: 100%;">
                            <div style="text-align: center; padding: 5px;" class="centered-text">
                                <h3 style="letter-spacing: 0px; margin-top: 0px; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';">'.$title.'</h3>
                                <p style="font-family: '.$font.'; font-size: '.$desc_font_size.'px; color:'.$desc_color.';">'.$description.'</p>
                            </div>
                        </div>
                </div>
                        <img style="width:'.$image_width.'px; height:'.$image_height.'px; transition: all 1s ease; animation-duration: 1s;" src="'.$image[0].'" class="wcp-caption-image">

                </div>
            </a>
        </div>';
        }
