<?php
if ( $style=='square2' && $square2_effects=='effect1' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-circle ahe-square-teal '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px; color:'.$heading_color.';" >'.$title.'</h1>
                        </div></a>';
        }

        if ( $style=='square2' && $square2_effects=='effect2' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-circle strawberry '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }

        if ( $style=='square2' && $square2_effects=='effect3' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-circle grape '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }

        if ( $style=='square2' && $square2_effects=='effect4' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-circle orange '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect5' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-rumb ahe-square-teal '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect6' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-rumb strawberry '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect7' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-rumb grape '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect8' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-rumb orange '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect9' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-up ahe-square-teal '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect10' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-up strawberry '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect11' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-up grape '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect12' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-up orange '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect13' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-side ahe-square-teal '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect14' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-side strawberry '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }
        
        if ( $style=='square2' && $square2_effects=='effect15' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-side grape '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }        
        
        if ( $style=='square2' && $square2_effects=='effect16' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="burst-side orange '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }         
        
        if ( $style=='square2' && $square2_effects=='effect17' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="triangle ahe-square-teal '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }        
        
        if ( $style=='square2' && $square2_effects=='effect18' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="triangle strawberry '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }        
        
        if ( $style=='square2' && $square2_effects=='effect19' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="triangle grape '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }        
        
        if ( $style=='square2' && $square2_effects=='effect20' ){
    
            $output .= '<a class="square2_link" href="' . $link['url'] . '" title="' . $link['title'] . '" target="' . $link['target'] . '">
                        <div id="square-box" class="triangle orange '.$css_class.'" style="height: '.$image_height.'px; width: '.$image_width.'px;">
                            <div class="ahe-square"></div>
                            <img src="'.$image[0].'">
                            <h1 style="top: '.$move_texts.'%; font-family: '.$font.'; font-size: '.$heading_font_size.'px;" >'.$title.'</h1>
                        </div></a>';
        }        
        
        