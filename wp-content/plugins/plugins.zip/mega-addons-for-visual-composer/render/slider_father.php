<div class="bx-wrapper" style="max-width: <?php echo $width; ?>; width: 100%; margin: auto;">
	<ul class="bxslider">
		<?php echo $content; ?>
	</ul>
</div>