<?php  
$texttype_params = array(
		array(
            "type" 			=> 	"textarea_html",
			"heading" 		=> 	__( 'Title', 'texttype-vc' ),
			"param_name" 	=> 	"content",
			"description" 	=> 	__( 'write each text inside <p></p> tag', 'texttype-vc' ),
			"group" 		=> 	'General',
        ),

    );
?>